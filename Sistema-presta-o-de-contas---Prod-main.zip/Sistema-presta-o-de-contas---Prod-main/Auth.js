const USER_HEADERS = [
  'id',
  'nome',
  'email',
  'senha_hash',
  'salt',
  'role',
  'is_master',
  'ativo',
  'ultimo_login',
  'criado_em',
  'atualizado_em'
];

function requireSession_(token) {
  token = String(token || '');
  const raw = CacheService.getScriptCache().get('session_' + token);

  if (!raw) {
    throw new Error('Sessão expirada. Faça login novamente.');
  }

  return JSON.parse(raw);
}

function requireAdminSession_(token) {
  const user = requireSession_(token);

  if (String(user.role || '').toLowerCase() !== 'admin') {
    throw new Error('Acesso negado. Só admin pode editar. Democracia é linda, mas permissões existem por um motivo.');
  }

  return user;
}

function getInitialSecureUsersRows_() {
  const now = new Date();
  const salt = createSalt_();

  return [
    USER_HEADERS,
    [
      1,
      'Administrador',
      'admin@local.com',
      hashPassword_('admin123', salt),
      salt,
      'admin',
      true,
      true,
      '',
      now,
      now
    ]
  ];
}

function ensureUserSecuritySchema_() {
  const ss = getSpreadsheet_();
  let sh = ss.getSheetByName('Usuarios');

  if (!sh) {
    createOrResetSheet_(ss, 'Usuarios', getInitialSecureUsersRows_());
    invalidateUsersCache_();
    return;
  }

  const values = sh.getDataRange().getValues();

  if (!values.length || !values[0].length) {
    createOrResetSheet_(ss, 'Usuarios', getInitialSecureUsersRows_());
    invalidateUsersCache_();
    return;
  }

  const headers = values[0].map(h => String(h).trim());
  const hasSecureColumns = headers.includes('senha_hash') && headers.includes('salt');
  const sameHeaders = USER_HEADERS.every((h, i) => headers[i] === h) && headers.length === USER_HEADERS.length;

  if (hasSecureColumns && sameHeaders) {
    CacheService.getScriptCache().put('usuarios_schema_ok_v11', '1', 21600);
    return;
  }

  const now = new Date();
  const migrated = [USER_HEADERS];

  values.slice(1)
    .filter(row => row.join('') !== '')
    .forEach((row, index) => {
      const old = objectFromRow_(headers, row);
      const email = String(old.email || old.Email || '').trim().toLowerCase();
      if (!email) return;

      let salt = old.salt || '';
      let senhaHash = old.senha_hash || '';

      if (!senhaHash || !salt) {
        const plain = String(old.senha || old.password || (email === 'admin@local.com' ? 'admin123' : '') || '');
        if (plain) {
          salt = createSalt_();
          senhaHash = hashPassword_(plain, salt);
        }
      }

      migrated.push([
        old.id || index + 1,
        old.nome || old.name || 'Usuário',
        email,
        senhaHash,
        salt,
        old.role || 'viewer',
        normalizeBool_(old.is_master),
        normalizeBool_(old.ativo, true),
        old.ultimo_login || '',
        old.criado_em || now,
        now
      ]);
    });

  if (migrated.length === 1) {
    const adminRows = getInitialSecureUsersRows_();
    migrated.push(adminRows[1]);
  }

  createOrResetSheet_(ss, 'Usuarios', migrated);
  autoResizeAll_(ss);
  invalidateUsersCache_();
  CacheService.getScriptCache().put('usuarios_schema_ok_v11', '1', 21600);
}

function readUsers_() {
  return readUsersCached_();
}

function readUsersFromSheet_() {
  const ss = getSpreadsheet_();
  const sh = ss.getSheetByName('Usuarios');
  if (!sh) return [];

  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values[0].map(h => String(h).trim());

  return values
    .slice(1)
    .filter(r => r.join('') !== '')
    .map(row => objectFromRow_(headers, row));
}

function readUsersCached_() {
  const cache = CacheService.getScriptCache();
  const raw = cache.get('usuarios_cache_v11');

  if (raw) {
    try {
      return JSON.parse(raw);
    } catch (e) {
      cache.remove('usuarios_cache_v11');
    }
  }

  const users = readUsersFromSheet_();

  // Cache curto: acelera login sem deixar alteração de usuário presa por muito tempo.
  // Funções de criar/editar/excluir usuário também limpam este cache.
  cache.put('usuarios_cache_v11', JSON.stringify(users), 120);

  return users;
}

function invalidateUsersCache_() {
  const cache = CacheService.getScriptCache();
  cache.remove('usuarios_cache_v11');
  cache.remove('usuarios_schema_ok_v11');
}

function ensureUserSecuritySchemaFast_() {
  const cache = CacheService.getScriptCache();

  if (cache.get('usuarios_schema_ok_v11') === '1') {
    return;
  }

  ensureUserSecuritySchema_();
  cache.put('usuarios_schema_ok_v11', '1', 21600);
}

function sanitizeUser_(user) {
  const copy = Object.assign({}, user || {});
  delete copy.senha;
  delete copy.password;
  delete copy.senha_hash;
  delete copy.salt;
  return copy;
}

function createSalt_() {
  return Utilities.getUuid().replace(/-/g, '') + String(Date.now()) + Math.floor(Math.random() * 1000000);
}

function hashPassword_(password, salt) {
  const raw = String(salt || '') + '|' + String(password || '');
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, raw);
  return bytesToHex_(bytes);
}

function verifyPassword_(password, salt, expectedHash) {
  if (!salt || !expectedHash) return false;
  const attempt = hashPassword_(password, salt);
  return constantTimeEquals_(attempt, String(expectedHash));
}

function bytesToHex_(bytes) {
  return bytes.map(b => {
    const v = (b < 0 ? b + 256 : b).toString(16);
    return v.length === 1 ? '0' + v : v;
  }).join('');
}

function constantTimeEquals_(a, b) {
  a = String(a || '');
  b = String(b || '');

  if (a.length !== b.length) return false;

  let mismatch = 0;
  for (let i = 0; i < a.length; i++) {
    mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return mismatch === 0;
}

function normalizeBool_(value, defaultValue) {
  if (value === '' || value === null || typeof value === 'undefined') {
    return Boolean(defaultValue);
  }
  if (typeof value === 'boolean') return value;
  const s = String(value).trim().toLowerCase();
  return !['false', 'falso', '0', 'não', 'nao', 'no'].includes(s);
}

function nextUserId_() {
  const users = readUsers_();
  return users.reduce((max, u) => Math.max(max, Number(u.id || 0)), 0) + 1;
}

function updateUserLastLogin_(email) {
  const sh = getSpreadsheet_().getSheetByName('Usuarios');
  const values = sh.getDataRange().getValues();
  const headers = values[0].map(String);
  const emailCol = headers.indexOf('email') + 1;
  const lastCol = headers.indexOf('ultimo_login') + 1;
  const updatedCol = headers.indexOf('atualizado_em') + 1;

  if (!emailCol || !lastCol) return;

  for (let i = 1; i < values.length; i++) {
    if (String(values[i][emailCol - 1] || '').toLowerCase().trim() === String(email).toLowerCase().trim()) {
      sh.getRange(i + 1, lastCol).setValue(new Date());
      if (updatedCol) sh.getRange(i + 1, updatedCol).setValue(new Date());
      return;
    }
  }
}

function failedLoginKey_(email) {
  return 'failed_login_' + Utilities.base64EncodeWebSafe(String(email || '').toLowerCase()).slice(0, 80);
}

function checkLoginRateLimit_(email) {
  const cache = CacheService.getScriptCache();
  const count = Number(cache.get(failedLoginKey_(email)) || 0);

  if (count >= APP.MAX_LOGIN_ATTEMPTS) {
    throw new Error('Muitas tentativas de login. Aguarde alguns minutos e tente novamente.');
  }
}

function registerFailedLogin_(email) {
  const cache = CacheService.getScriptCache();
  const key = failedLoginKey_(email);
  const count = Number(cache.get(key) || 0) + 1;
  cache.put(key, String(count), APP.LOCK_SECONDS);
}

function clearFailedLogin_(email) {
  CacheService.getScriptCache().remove(failedLoginKey_(email));
}
