const APP = {
  SPREADSHEET_ID: '',
  TZ: 'America/Sao_Paulo',
  SESSION_SECONDS: 21600,
  MAX_LOGIN_ATTEMPTS: 5,
  LOCK_SECONDS: 600,
  UPDATE_LAST_LOGIN_ON_LOGIN: false,
  DATA_CACHE_SECONDS: 180
};

function doGet() {
  const template = HtmlService.createTemplateFromFile('index');

  return template
    .evaluate()
    .setTitle('Prestação de Contas')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function setupDatabase() {
  const ss = getSpreadsheet_();

  createOrResetSheet_(ss, 'Config', [
    ['chave', 'valor'],
    ['periodo', 'Fevereiro a Abril - 2026'],
    ['missao', 'Miss\u00e3o Aparecida'],
    ['comunidade', 'Comunidade Cat\u00f3lica Shalom'],
    ['subtitulo', 'Relat\u00f3rio de Gest\u00e3o Financeira'],
    ['saldo_inicial', 10296.48],
    ['meses', 'Fevereiro,Mar\u00e7o,Abril'],
    ['slides_visiveis', 'capa,resumo,receita_despesa,receita_periodo,cal10,detalhes_receitas,detalhes_despesas,cal5,asm_percentuais,asm_partilha_obra,asm_benfeitor_paz,asm_evangelizacao,asm_eventos,asm_secretaria,asm_final']
  ]);

  createOrResetSheet_(ss, 'Usuarios', getInitialSecureUsersRows_());

  createOrResetSheet_(ss, 'Receitas', getInitialRevenueRows_());
  createOrResetSheet_(ss, 'Despesas', getInitialExpenseRows_());
  createOrResetSheet_(ss, 'CAL10', getInitialCal10Rows_());
  createOrResetSheet_(ss, 'CAL5', getInitialCal5Rows_());
  createOrResetSheet_(ss, 'Assembleia', getInitialAssembleiaRows_());
  createOrResetSheet_(ss, 'AssembleiaEventos', getInitialAssembleiaEventosRows_());

  autoResizeAll_(ss);
  invalidateUsersCache_();
  invalidateFinancialDataCache_();
  return { ok: true, spreadsheetUrl: ss.getUrl() };
}


function login(email, senha) {
  // Login ultra-rápido: valida somente usuário/senha e cria sessão.
  // Não carrega dados financeiros e não migra estrutura durante o login.
  // Para corrigir/migrar usuários, rode migrarUsuariosParaLoginSeguro() manualmente uma vez.

  email = String(email || '').trim().toLowerCase();
  senha = String(senha || '');

  if (!email || !senha) {
    throw new Error('Informe e-mail e senha.');
  }

  checkLoginRateLimit_(email);

  const matchingUsers = readUsersCached_().filter(u =>
    String(u.email || '').toLowerCase().trim() === email &&
    String(u.ativo).toLowerCase() !== 'false'
  );

  if (matchingUsers.length > 1) {
    throw new Error('Existe mais de um usuário ativo com este e-mail. Deixe somente um ativo na aba Usuarios.');
  }

  const user = matchingUsers[0];
  const valid = user && verifyPassword_(senha, user.salt, user.senha_hash);

  if (!valid) {
    registerFailedLogin_(email);
    throw new Error('Login inválido. E-mail ou senha não conferem.');
  }

  clearFailedLogin_(email);

  if (APP.UPDATE_LAST_LOGIN_ON_LOGIN === true) {
    updateUserLastLogin_(email);
    invalidateUsersCache_();
  }

  const publicUser = sanitizeUser_(user);
  publicUser.google_email = Session.getActiveUser().getEmail() || '';

  const token = Utilities.getUuid() + '-' + Utilities.getUuid();
  CacheService.getScriptCache().put('session_' + token, JSON.stringify(publicUser), APP.SESSION_SECONDS);

  return { token, user: publicUser, expiresIn: APP.SESSION_SECONDS };
}

function logout(token) {
  if (token) CacheService.getScriptCache().remove('session_' + token);
  return true;
}

function validarSessao(token) {
  try {
    const user = requireSession_(token);
    return { valid: true, user: user, expiresIn: APP.SESSION_SECONDS };
  } catch (err) {
    return { valid: false };
  }
}

function getInitialDataForApp(token) {
  const user = requireSession_(token);
  const data = getFinancialData();
  return { user, data };
}

function saveAllData(token, payload) {
  requireAdminSession_(token);

  if (!payload) throw new Error('Nenhum dado recebido.');

  saveConfig_(payload.config || {});
  replaceTable_('Receitas', payload.receitas || []);
  replaceTable_('Despesas', payload.despesas || []);
  replaceCal_('CAL10', payload.cal10 || []);
  replaceCal_('CAL5', payload.cal5 || []);
  saveAssembleia_(payload.assembleia || {});
  replaceAssembleiaEventos_(payload.assembleia_eventos || []);

  invalidateFinancialDataCache_();
  return getFinancialData();
}

function listUsers(token) {
  requireAdminSession_(token);
  return readUsersCached_().map(sanitizeUser_);
}

function upsertUser(token, user) {
  requireAdminSession_(token);
  ensureUserSecuritySchema_();

  user = user || {};
  const email = String(user.email || '').trim().toLowerCase();
  if (!email) throw new Error('Informe o e-mail do usuário.');

  const ss = getSpreadsheet_();
  const sh = ss.getSheetByName('Usuarios');
  const values = sh.getDataRange().getValues();
  const headers = values[0].map(String);

  let rowIndex = -1;
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][headers.indexOf('email')] || '').toLowerCase().trim() === email) {
      rowIndex = i + 1;
      break;
    }
  }

  const now = new Date();
  const current = rowIndex > 0 ? objectFromRow_(headers, sh.getRange(rowIndex, 1, 1, headers.length).getValues()[0]) : {};
  const isNew = rowIndex < 0;
  const newPassword = String(user.senha || '');

  if (isNew && newPassword.length < 6) {
    throw new Error('A senha precisa ter pelo menos 6 caracteres.');
  }

  let salt = current.salt || '';
  let senhaHash = current.senha_hash || '';

  if (newPassword) {
    if (newPassword.length < 6) {
      throw new Error('A senha precisa ter pelo menos 6 caracteres.');
    }
    salt = createSalt_();
    senhaHash = hashPassword_(newPassword, salt);
  }

  const next = {
    id: current.id || nextUserId_(),
    nome: user.nome || current.nome || '',
    email: email,
    senha_hash: senhaHash,
    salt: salt,
    role: user.role || current.role || 'viewer',
    is_master: current.is_master || false,
    ativo: user.ativo === false || String(user.ativo).toLowerCase() === 'false' ? false : true,
    ultimo_login: current.ultimo_login || '',
    criado_em: current.criado_em || now,
    atualizado_em: now
  };

  const row = headers.map(h => h in next ? next[h] : '');

  if (rowIndex > 0) {
    sh.getRange(rowIndex, 1, 1, row.length).setValues([row]);
  } else {
    sh.appendRow(row);
  }

  invalidateUsersCache_();
  return listUsers(token);
}

function deleteUser(token, email) {
  const sessionUser = requireAdminSession_(token);
  ensureUserSecuritySchema_();

  email = String(email || '').trim().toLowerCase();
  if (!email) throw new Error('Informe o e-mail do usuário.');

  if (String(sessionUser.email || '').toLowerCase() === email) {
    throw new Error('Você não pode excluir seu próprio usuário conectado.');
  }

  const sh = getSpreadsheet_().getSheetByName('Usuarios');
  const values = sh.getDataRange().getValues();
  const headers = values[0].map(String);
  const emailCol = headers.indexOf('email');
  const roleCol = headers.indexOf('role');
  const ativoCol = headers.indexOf('ativo');

  const activeAdmins = values.slice(1).filter(r =>
    String(r[roleCol] || '').toLowerCase() === 'admin' &&
    String(r[ativoCol]).toLowerCase() !== 'false'
  );

  for (let i = values.length - 1; i >= 1; i--) {
    if (String(values[i][emailCol] || '').toLowerCase().trim() === email) {
      const isAdmin = String(values[i][roleCol] || '').toLowerCase() === 'admin';
      if (isAdmin && activeAdmins.length <= 1) {
        throw new Error('Não dá para excluir o último admin ativo. Até o caos precisa de um adulto responsável.');
      }
      sh.deleteRow(i + 1);
      break;
    }
  }

  invalidateUsersCache_();
  return listUsers(token);
}

function migrarUsuariosParaLoginSeguro() {
  ensureUserSecuritySchema_();
  invalidateUsersCache_();
  return 'Usuários migrados para senha protegida com hash e salt.';
}


/****************************************************************************************
 * v23 - Historico mensal, apresentacao por intervalo e dashboard anual
 ****************************************************************************************/

function ensureMonthlySheets_() {
  const ss = getSpreadsheet_();
  if (!ss.getSheetByName('LancamentosMensais')) createOrResetSheet_(ss, 'LancamentosMensais', [['ano','mes','tipo','categoria','valor']]);
  if (!ss.getSheetByName('CalMensal')) createOrResetSheet_(ss, 'CalMensal', [['ano','mes','tipo','previsto','realizado','fidelidade']]);
  if (!ss.getSheetByName('AssembleiaMensal')) createOrResetSheet_(ss, 'AssembleiaMensal', [['ano','mes','chave','valor']]);
  if (!ss.getSheetByName('EventosMensais')) createOrResetSheet_(ss, 'EventosMensais', [['ano','mes','evento','receita','despesa','superavit','observacao']]);
}

function repararAbasFaltantesSemResetar() {
  const ss = getSpreadsheet_();
  if (!ss.getSheetByName('Config')) {
    createOrResetSheet_(ss, 'Config', [
      ['chave','valor'],
      ['periodo','Fevereiro a Abril - 2026'],
      ['missao','Missao Aparecida'],
      ['comunidade','Comunidade Catolica Shalom'],
      ['subtitulo','Relatorio de Gestao Financeira'],
      ['saldo_inicial',0],
      ['meses','Fevereiro,Marco,Abril'],
      ['apresentacao_ano',new Date().getFullYear()],
      ['mes_inicio','Janeiro'],
      ['mes_fim','Marco'],
      ['slides_visiveis','capa,resumo,receita_despesa,receita_periodo,cal10,detalhes_receitas,detalhes_despesas,cal5,asm_percentuais,asm_partilha_obra,asm_benfeitor_paz,asm_evangelizacao,asm_eventos,asm_secretaria,asm_final']
    ]);
  } else {
    ensureConfigKey_('apresentacao_ano', new Date().getFullYear());
    ensureConfigKey_('mes_inicio', 'Janeiro');
    ensureConfigKey_('mes_fim', 'Marco');
  }
  if (!ss.getSheetByName('Usuarios')) createOrResetSheet_(ss, 'Usuarios', getInitialSecureUsersRows_());
  if (!ss.getSheetByName('Receitas')) createOrResetSheet_(ss, 'Receitas', getInitialRevenueRows_());
  if (!ss.getSheetByName('Despesas')) createOrResetSheet_(ss, 'Despesas', getInitialExpenseRows_());
  if (!ss.getSheetByName('CAL10')) createOrResetSheet_(ss, 'CAL10', getInitialCal10Rows_());
  if (!ss.getSheetByName('CAL5')) createOrResetSheet_(ss, 'CAL5', getInitialCal5Rows_());
  ensureAssembleiaSheets_();
  ensureMonthlySheets_();
  invalidateUsersCache_();
  invalidateFinancialDataCache_();
  return 'Abas verificadas e reparadas sem resetar as existentes.';
}

function ensureConfigKey_(key, value) {
  const ss = getSpreadsheet_();
  const sh = ss.getSheetByName('Config');
  if (!sh) return;
  const values = sh.getDataRange().getValues();
  const found = values.some((row, i) => i > 0 && String(row[0]) === key);
  if (!found) sh.appendRow([key, value]);
}

function normalizeMonth_(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function monthNames_() {
  return ['Janeiro','Fevereiro','Marco','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
}

function getMonthIndex_(mes) {
  const plain = normalizeMonth_(mes);
  return monthNames_().findIndex(m => normalizeMonth_(m) === plain);
}

function getMonthsRange_(start, end) {
  const months = monthNames_();
  let startIdx = getMonthIndex_(start);
  let endIdx = getMonthIndex_(end);
  if (startIdx < 0) startIdx = 0;
  if (endIdx < 0) endIdx = startIdx;
  if (endIdx < startIdx) endIdx = startIdx;
  return months.slice(startIdx, endIdx + 1);
}

function readMonthlyObjects_(sheetName) {
  ensureMonthlySheets_();
  const sh = getSpreadsheet_().getSheetByName(sheetName);
  if (!sh) return [];
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0].map(String);
  return values.slice(1).filter(r => r.join('') !== '').map(row => objectFromRow_(headers, row));
}

function replaceMonthlyRecords_(sheetName, keepPredicate, rowsToAppend, headers) {
  const ss = getSpreadsheet_();
  let sh = ss.getSheetByName(sheetName);
  if (!sh) {
    createOrResetSheet_(ss, sheetName, [headers]);
    sh = ss.getSheetByName(sheetName);
  }
  const values = sh.getDataRange().getValues();
  const oldHeaders = values.length ? values[0].map(String) : headers;
  const oldObjects = values.slice(1).filter(r => r.join('') !== '').map(row => objectFromRow_(oldHeaders, row));
  const kept = oldObjects.filter(keepPredicate).map(obj => headers.map(h => obj[h] === undefined ? '' : obj[h]));
  createOrResetSheet_(ss, sheetName, [headers].concat(kept).concat(rowsToAppend || []));
}

function loadMonthlyData(token, ano, mes) {
  requireSession_(token);
  ensureMonthlySheets_();
  ano = Number(ano || new Date().getFullYear());
  mes = String(mes || '').trim();
  const lanc = readMonthlyObjects_('LancamentosMensais');
  const cal = readMonthlyObjects_('CalMensal');
  const asm = readMonthlyObjects_('AssembleiaMensal');
  const eventos = readMonthlyObjects_('EventosMensais');
  const receitas = lanc.filter(r => Number(r.ano) === ano && String(r.mes) === mes && String(r.tipo) === 'Receita').map(r => ({ categoria: r.categoria, valor: Number(r.valor || 0) }));
  const despesas = lanc.filter(r => Number(r.ano) === ano && String(r.mes) === mes && String(r.tipo) === 'Despesa').map(r => ({ categoria: r.categoria, valor: Number(r.valor || 0) }));
  const cal10 = cal.find(r => Number(r.ano) === ano && String(r.mes) === mes && String(r.tipo) === 'CAL10') || {};
  const cal5 = cal.find(r => Number(r.ano) === ano && String(r.mes) === mes && String(r.tipo) === 'CAL5') || {};
  const assembleia = {};
  asm.filter(r => Number(r.ano) === ano && String(r.mes) === mes).forEach(r => assembleia[r.chave] = r.valor);
  const eventosMes = eventos.filter(r => Number(r.ano) === ano && String(r.mes) === mes).map(r => ({ evento: r.evento, receita: Number(r.receita || 0), despesa: Number(r.despesa || 0), superavit: Number(r.superavit || 0), observacao: r.observacao || '' }));
  if (!receitas.length) getInitialRevenueRows_().slice(1).forEach(r => receitas.push({ categoria: r[0], valor: 0 }));
  if (!despesas.length) getInitialExpenseRows_().slice(1).forEach(r => despesas.push({ categoria: r[0], valor: 0 }));
  return {
    ano, mes, receitas, despesas,
    cal10: { previsto: Number(cal10.previsto || 0), realizado: Number(cal10.realizado || 0), fidelidade: Number(cal10.fidelidade || calcFidelidade_(cal10.realizado, cal10.previsto)) },
    cal5: { previsto: Number(cal5.previsto || 0), realizado: Number(cal5.realizado || 0), fidelidade: Number(cal5.fidelidade || calcFidelidade_(cal5.realizado, cal5.previsto)) },
    assembleia,
    assembleia_eventos: eventosMes.length ? eventosMes : getInitialAssembleiaEventosRows_().slice(1).map(r => ({ evento: r[0], receita: 0, despesa: 0, superavit: 0, observacao: '' }))
  };
}

function saveMonthlyData(token, payload) {
  requireAdminSession_(token);
  ensureMonthlySheets_();
  payload = payload || {};
  const ano = Number(payload.ano || new Date().getFullYear());
  const mes = String(payload.mes || '').trim();
  if (!ano || !mes) throw new Error('Informe ano e mes para salvar.');
  replaceMonthlyRecords_('LancamentosMensais', row => !(Number(row.ano) === ano && String(row.mes) === mes), [
    ...(payload.receitas || []).map(r => [ano, mes, 'Receita', r.categoria || '', Number(r.valor || 0)]),
    ...(payload.despesas || []).map(r => [ano, mes, 'Despesa', r.categoria || '', Number(r.valor || 0)])
  ], ['ano','mes','tipo','categoria','valor']);
  replaceMonthlyRecords_('CalMensal', row => !(Number(row.ano) === ano && String(row.mes) === mes), [
    [ano, mes, 'CAL10', Number(payload.cal10 && payload.cal10.previsto || 0), Number(payload.cal10 && payload.cal10.realizado || 0), Number(payload.cal10 && payload.cal10.fidelidade || calcFidelidade_(payload.cal10 && payload.cal10.realizado, payload.cal10 && payload.cal10.previsto))],
    [ano, mes, 'CAL5', Number(payload.cal5 && payload.cal5.previsto || 0), Number(payload.cal5 && payload.cal5.realizado || 0), Number(payload.cal5 && payload.cal5.fidelidade || calcFidelidade_(payload.cal5 && payload.cal5.realizado, payload.cal5 && payload.cal5.previsto))]
  ], ['ano','mes','tipo','previsto','realizado','fidelidade']);
  const asmRows = [];
  const asm = payload.assembleia || {};
  Object.keys(asm).forEach(k => asmRows.push([ano, mes, k, asm[k]]));
  replaceMonthlyRecords_('AssembleiaMensal', row => !(Number(row.ano) === ano && String(row.mes) === mes), asmRows, ['ano','mes','chave','valor']);
  const eventosRows = (payload.assembleia_eventos || []).map(r => [ano, mes, r.evento || '', Number(r.receita || 0), Number(r.despesa || 0), Number(r.superavit || (Number(r.receita || 0) - Number(r.despesa || 0))), r.observacao || '']);
  replaceMonthlyRecords_('EventosMensais', row => !(Number(row.ano) === ano && String(row.mes) === mes), eventosRows, ['ano','mes','evento','receita','despesa','superavit','observacao']);
  invalidateFinancialDataCache_();
  return { ok: true, message: 'Mes salvo com sucesso.', data: loadMonthlyData(token, ano, mes) };
}

function savePresentationConfig(token, config) {
  requireAdminSession_(token);
  config = config || {};
  const current = getConfig_();
  current.apresentacao_ano = Number(config.ano || current.apresentacao_ano || new Date().getFullYear());
  current.mes_inicio = config.mes_inicio || current.mes_inicio || 'Janeiro';
  current.mes_fim = config.mes_fim || current.mes_fim || current.mes_inicio || 'Janeiro';
  const meses = getMonthsRange_(current.mes_inicio, current.mes_fim);
  current.periodo = meses[0] === meses[meses.length - 1] ? meses[0] + ' - ' + current.apresentacao_ano : meses[0] + ' a ' + meses[meses.length - 1] + ' - ' + current.apresentacao_ano;
  current.meses = meses.join(',');
  saveConfig_(current);
  invalidateFinancialDataCache_();
  return getFinancialData(true);
}

function getFinancialData(forceRefresh) {
  const cache = CacheService.getScriptCache();
  if (!forceRefresh) {
    const cached = cache.get('financial_data_cache_v23');
    if (cached) { try { return JSON.parse(cached); } catch (err) {} }
  }
  const ss = getSpreadsheet_();
  ensureSheetsExist_(ss);
  ensureMonthlySheets_();
  const config = getConfig_();
  const ano = Number(config.apresentacao_ano || new Date().getFullYear());
  const meses = getMonthsRange_(config.mes_inicio || 'Janeiro', config.mes_fim || 'Marco');
  const monthly = buildPeriodDataFromMonthly_(ano, meses, false);
  if (monthly.hasData) {
    const data = Object.assign(monthly, { config: Object.assign({}, config, { apresentacao_ano: ano, meses: meses.join(','), periodo: meses[0] === meses[meses.length - 1] ? meses[0] + ' - ' + ano : meses[0] + ' a ' + meses[meses.length - 1] + ' - ' + ano }) });
    cache.put('financial_data_cache_v23', JSON.stringify(data), APP.DATA_CACHE_SECONDS || 180);
    return data;
  }
  const receitas = readTable_('Receitas');
  const despesas = readTable_('Despesas');
  const cal10 = readCal_('CAL10');
  const cal5 = readCal_('CAL5');
  const assembleia = readAssembleia_();
  const assembleia_eventos = readAssembleiaEventos_();
  const legacyMeses = String(config.meses || 'Fevereiro,Marco,Abril').split(',').map(s => s.trim());
  const summary = buildSummary_(receitas, despesas, legacyMeses, Number(config.saldo_inicial || 0));
  const data = { config, meses: legacyMeses, receitas, despesas, cal10, cal5, assembleia, assembleia_eventos, summary, annual: buildAnnualData_(ano) };
  cache.put('financial_data_cache_v23', JSON.stringify(data), APP.DATA_CACHE_SECONDS || 180);
  return data;
}

function invalidateFinancialDataCache_() {
  CacheService.getScriptCache().remove('financial_data_cache_v23');
}

function buildPeriodDataFromMonthly_(ano, meses, includeAnnual) {
  const lanc = readMonthlyObjects_('LancamentosMensais').filter(r => Number(r.ano) === ano && meses.includes(String(r.mes)));
  const cal = readMonthlyObjects_('CalMensal').filter(r => Number(r.ano) === ano && meses.includes(String(r.mes)));
  const asmRows = readMonthlyObjects_('AssembleiaMensal').filter(r => Number(r.ano) === ano && meses.includes(String(r.mes)));
  const eventRows = readMonthlyObjects_('EventosMensais').filter(r => Number(r.ano) === ano && meses.includes(String(r.mes)));
  const hasData = Boolean(lanc.length || cal.length || asmRows.length || eventRows.length);
  const receitas = buildCategoryRowsFromMonthly_(lanc, meses, 'Receita');
  const despesas = buildCategoryRowsFromMonthly_(lanc, meses, 'Despesa');
  const receitasMes = {};
  const despesasMes = {};
  const resultadoMes = {};
  meses.forEach((m, i) => {
    receitasMes[m] = receitas.reduce((s, r) => s + Number((r.valores || [])[i] || 0), 0);
    despesasMes[m] = despesas.reduce((s, r) => s + Number((r.valores || [])[i] || 0), 0);
    resultadoMes[m] = receitasMes[m] - despesasMes[m];
  });
  const totalReceitas = Object.values(receitasMes).reduce((a,b)=>a+b,0);
  const totalDespesas = Object.values(despesasMes).reduce((a,b)=>a+b,0);
  const saldoInicial = Number(getConfig_().saldo_inicial || 0);
  const saldoFinal = saldoInicial + totalReceitas - totalDespesas;
  const cal10 = buildCalRowsFromMonthly_(cal, meses, 'CAL10');
  const cal5 = buildCalRowsFromMonthly_(cal, meses, 'CAL5');
  const assembleia = {};
  asmRows.forEach(r => assembleia[r.chave] = r.valor);
  const assembleia_eventos = eventRows.map(r => ({ evento: r.evento, receita: Number(r.receita || 0), despesa: Number(r.despesa || 0), superavit: Number(r.superavit || 0), observacao: r.observacao || '' }));
  const data = {
    hasData, ano, meses, receitas, despesas, cal10, cal5, assembleia, assembleia_eventos,
    summary: { receitasMes, despesasMes, resultadoMes, totalReceitas, totalDespesas, saldoInicial, saldoFinal, comprometimento: totalReceitas ? totalDespesas / totalReceitas * 100 : 0 }
  };
  if (includeAnnual !== false) data.annual = buildAnnualData_(ano);
  return data;
}

function buildCategoryRowsFromMonthly_(lanc, meses, tipo) {
  const cats = {};
  lanc.filter(r => String(r.tipo) === tipo).forEach(r => {
    const cat = r.categoria || '';
    if (!cats[cat]) cats[cat] = { categoria: cat, valores: meses.map(() => 0) };
    const idx = meses.indexOf(String(r.mes));
    if (idx >= 0) cats[cat].valores[idx] += Number(r.valor || 0);
  });
  return Object.values(cats).map(row => Object.assign(row, { fevereiro: Number(row.valores[0] || 0), marco: Number(row.valores[1] || 0), abril: Number(row.valores[2] || 0) }));
}

function buildCalRowsFromMonthly_(cal, meses, tipo) {
  return meses.map(m => {
    const r = cal.find(row => String(row.tipo) === tipo && String(row.mes) === m) || {};
    const previsto = Number(r.previsto || 0);
    const realizado = Number(r.realizado || 0);
    return { mes: m, previsto, realizado, fidelidade: Number(r.fidelidade || calcFidelidade_(realizado, previsto)) };
  });
}

function buildAnnualData_(ano) {
  return buildPeriodDataFromMonthly_(ano, monthNames_(), false);
}

function getAnnualDashboardData(token, ano) {
  requireSession_(token);
  ensureMonthlySheets_();
  return buildAnnualData_(Number(ano || new Date().getFullYear()));
}