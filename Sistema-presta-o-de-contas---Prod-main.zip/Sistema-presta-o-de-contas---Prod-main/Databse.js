function getSpreadsheet_() {
  if (APP.SPREADSHEET_ID) {
    return SpreadsheetApp.openById(APP.SPREADSHEET_ID);
  }

  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) return active;

  throw new Error('Crie uma planilha vinculada ao Apps Script ou preencha APP.SPREADSHEET_ID.');
}

function ensureSheetsExist_(ss) {
  // Não chama setupDatabase aqui para evitar resetar dados existentes.
  if (!ss.getSheetByName('Config')) {
    createOrResetSheet_(ss, 'Config', [
      ['chave', 'valor'],
      ['periodo', 'Fevereiro a Abril - 2026'],
      ['missao', 'Missão Aparecida'],
      ['comunidade', 'Comunidade Católica Shalom'],
      ['subtitulo', 'Relatório de Gestão Financeira'],
      ['saldo_inicial', 0],
      ['meses', 'Fevereiro,Março,Abril'],
      ['slides_visiveis', 'capa,resumo,receita_despesa,receita_periodo,cal10,detalhes_receitas,detalhes_despesas,cal5,asm_percentuais,asm_partilha_obra,asm_benfeitor_paz,asm_evangelizacao,asm_eventos,asm_secretaria,asm_final']
    ]);
  }
  if (!ss.getSheetByName('Usuarios')) createOrResetSheet_(ss, 'Usuarios', getInitialSecureUsersRows_());
  if (!ss.getSheetByName('Receitas')) createOrResetSheet_(ss, 'Receitas', getInitialRevenueRows_());
  if (!ss.getSheetByName('Despesas')) createOrResetSheet_(ss, 'Despesas', getInitialExpenseRows_());
  if (!ss.getSheetByName('CAL10')) createOrResetSheet_(ss, 'CAL10', getInitialCal10Rows_());
  if (!ss.getSheetByName('CAL5')) createOrResetSheet_(ss, 'CAL5', getInitialCal5Rows_());
  ensureAssembleiaSheets_();
}

function createOrResetSheet_(ss, name, rows) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);

  sh.clear();

  if (rows && rows.length) {
    sh.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
    sh.getRange(1, 1, 1, rows[0].length).setFontWeight('bold').setBackground('#b67a00').setFontColor('#ffffff');
  }

  sh.setFrozenRows(1);
  return sh;
}

function autoResizeAll_(ss) {
  ss.getSheets().forEach(sh => sh.autoResizeColumns(1, Math.max(1, sh.getLastColumn())));
}

function getConfig_() {
  const ss = getSpreadsheet_();
  let sh = ss.getSheetByName('Config');
  if (!sh) {
    ensureSheetsExist_(ss);
    sh = ss.getSheetByName('Config');
  }
  if (!sh) throw new Error('Aba Config não encontrada. Rode repararAbasFaltantesSemResetar.');
  const values = sh.getDataRange().getValues().slice(1);

  return values.reduce((acc, [k, v]) => {
    if (k) acc[String(k)] = v;
    return acc;
  }, {});
}

function saveConfig_(config) {
  const rows = [['chave', 'valor']];
  rows.push(['periodo', config.periodo || 'Fevereiro a Abril - 2026']);
  rows.push(['missao', config.missao || 'Miss\u00e3o Aparecida']);
  rows.push(['comunidade', config.comunidade || 'Comunidade Cat\u00f3lica Shalom']);
  rows.push(['subtitulo', config.subtitulo || 'Relat\u00f3rio de Gest\u00e3o Financeira']);
  rows.push(['saldo_inicial', Number(config.saldo_inicial || 0)]);
  rows.push(['meses', Array.isArray(config.meses) ? config.meses.join(',') : (config.meses || 'Fevereiro,Mar\u00e7o,Abril')]);
  rows.push(['slides_visiveis', Array.isArray(config.slides_visiveis) ? config.slides_visiveis.join(',') : (config.slides_visiveis || 'capa,resumo,receita_despesa,receita_periodo,cal10,detalhes_receitas,detalhes_despesas,cal5,asm_percentuais,asm_partilha_obra,asm_benfeitor_paz,asm_evangelizacao,asm_eventos,asm_secretaria,asm_final')]);

  createOrResetSheet_(getSpreadsheet_(), 'Config', rows);
}

function readTable_(sheetName) {
  const ss = getSpreadsheet_();
  let sh = ss.getSheetByName(sheetName);
  if (!sh) {
    ensureSheetsExist_(ss);
    sh = ss.getSheetByName(sheetName);
  }
  if (!sh) throw new Error('Aba ' + sheetName + ' não encontrada. Rode repararAbasFaltantesSemResetar.');
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values[0].map(h => String(h).trim());

  return values
    .slice(1)
    .filter(r => r.join('') !== '')
    .map(row => objectFromRow_(headers, row));
}

function replaceTable_(sheetName, rows) {
  const output = [['categoria', 'fevereiro', 'marco', 'abril']];

  rows.forEach(r => {
    output.push([
      r.categoria || r.category || '',
      Number(r.fevereiro || 0),
      Number(r.marco || 0),
      Number(r.abril || 0)
    ]);
  });

  createOrResetSheet_(getSpreadsheet_(), sheetName, output);
}

function readCal_(sheetName) {
  const ss = getSpreadsheet_();
  let sh = ss.getSheetByName(sheetName);
  if (!sh) {
    ensureSheetsExist_(ss);
    sh = ss.getSheetByName(sheetName);
  }
  if (!sh) throw new Error('Aba ' + sheetName + ' não encontrada. Rode repararAbasFaltantesSemResetar.');
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];

  const headers = values[0].map(h => String(h).trim());

  return values
    .slice(1)
    .filter(r => r.join('') !== '')
    .map(row => objectFromRow_(headers, row));
}

function replaceCal_(sheetName, rows) {
  const output = [['mes', 'previsto', 'realizado', 'fidelidade']];

  rows.forEach(r => {
    output.push([
      r.mes || '',
      Number(r.previsto || 0),
      Number(r.realizado || 0),
      Number(r.fidelidade || calcFidelidade_(r.realizado, r.previsto))
    ]);
  });

  createOrResetSheet_(getSpreadsheet_(), sheetName, output);
}


function getAssembleiaEventosSheet_() {
  const ss = getSpreadsheet_();

  // Nome oficial da versão atual.
  let sh = ss.getSheetByName('AssembleiaEventos');
  if (sh) return sh;

  // Compatibilidade com versões antigas que usavam este nome.
  sh = ss.getSheetByName('EventosAssembleia');
  if (sh) {
    try {
      sh.setName('AssembleiaEventos');
      return ss.getSheetByName('AssembleiaEventos');
    } catch (err) {
      return sh;
    }
  }

  return null;
}

function ensureAssembleiaSheets_() {
  const ss = getSpreadsheet_();
  if (!ss.getSheetByName('Assembleia')) {
    createOrResetSheet_(ss, 'Assembleia', getInitialAssembleiaRows_());
  }
  if (!getAssembleiaEventosSheet_()) {
    createOrResetSheet_(ss, 'AssembleiaEventos', getInitialAssembleiaEventosRows_());
  }
}

function readAssembleia_() {
  ensureAssembleiaSheets_();
  const sh = getSpreadsheet_().getSheetByName('Assembleia');
  const values = sh.getDataRange().getValues().slice(1);
  return values.reduce((acc, row) => {
    const key = String(row[0] || '').trim();
    if (key) acc[key] = row[1];
    return acc;
  }, {});
}

function saveAssembleia_(data) {
  data = data || {};
  const defaults = readAssembleia_();
  const merged = Object.assign({}, defaults, data);
  const rows = [['chave', 'valor']];
  Object.keys(merged).sort().forEach(k => rows.push([k, merged[k]]));
  createOrResetSheet_(getSpreadsheet_(), 'Assembleia', rows);
}

function readAssembleiaEventos_() {
  ensureAssembleiaSheets_();
  const sh = getAssembleiaEventosSheet_();
  if (!sh) return [];
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0].map(h => String(h).trim());
  return values.slice(1).filter(r => r.join('') !== '').map(row => objectFromRow_(headers, row));
}

function replaceAssembleiaEventos_(rows) {
  const output = [['evento', 'receita', 'despesa', 'superavit', 'observacao']];
  (rows || []).forEach(r => output.push([
    r.evento || '',
    Number(r.receita || 0),
    Number(r.despesa || 0),
    Number(r.superavit || (Number(r.receita || 0) - Number(r.despesa || 0))),
    r.observacao || ''
  ]));
  const ss = getSpreadsheet_();
  const existing = getAssembleiaEventosSheet_();
  const sheetName = existing ? existing.getName() : 'AssembleiaEventos';
  createOrResetSheet_(ss, sheetName, output);
}

function getInitialAssembleiaRows_() {
  return [
    ['chave', 'valor'],
    ['total_irmaos_obra', 52],
    ['total_bf', 24],
    ['total_pessoas_obra', 52],
    ['casais', ''],
    ['jovens', 2],
    ['adultos', ''],
    ['acao_renascer_participantes', 45],
    ['grupo_shalom_participantes', 15],
    ['missa_cura_alcancadas', 60],
    ['secretaria_consultas', 'X'],
    ['secretaria_exames', 'X'],
    ['secretaria_medicamentos', 'X'],
    ['secretaria_total', 'X'],
    ['secretaria_irmaos_socorridos', 'X'],
    ['secretaria_obs', 'Estes valores correspondem à soma dos 3 meses.'],
    ['mensagem_final', 'Tudo isso aconteceu graças a você, que foi instrumento da providência divina na vida da comunidade e da Igreja.'],
    ['pix_texto', 'Chave PIX para os 10%'],
    ['whatsapp_texto', 'Para falar com o WhatsApp da Providência']
  ];
}

function getInitialAssembleiaEventosRows_() {
  return [
    ['evento', 'receita', 'despesa', 'superavit', 'observacao'],
    ['Renascer 2026', 10164.30, 5463.45, 4700.85, 'Estes valores correspondem ao fechamento do evento.'],
    ['Retiro de Semana Santa 2026', 1590.00, 1284.60, 305.40, 'Estes valores correspondem ao fechamento do evento.']
  ];
}

function objectFromRow_(headers, row) {
  return headers.reduce((obj, h, i) => {
    obj[h] = row[i];
    return obj;
  }, {});
}

function sumByMonth_(rows, key) {
  return rows.reduce((total, r) => total + Number(r[key] || 0), 0);
}

function rowTotal_(row) {
  return Number(row.fevereiro || 0) + Number(row.marco || 0) + Number(row.abril || 0);
}

function buildSummary_(receitas, despesas, meses, saldoInicial) {
  const keys = ['fevereiro', 'marco', 'abril'];
  const receitasMes = {};
  const despesasMes = {};
  const resultadoMes = {};

  keys.forEach((k, i) => {
    const label = meses[i] || k;
    receitasMes[label] = sumByMonth_(receitas, k);
    despesasMes[label] = sumByMonth_(despesas, k);
    resultadoMes[label] = receitasMes[label] - despesasMes[label];
  });

  const totalReceitas = Object.values(receitasMes).reduce((a, b) => a + b, 0);
  const totalDespesas = Object.values(despesasMes).reduce((a, b) => a + b, 0);
  const saldoFinal = saldoInicial + totalReceitas - totalDespesas;

  return { receitasMes, despesasMes, resultadoMes, totalReceitas, totalDespesas, saldoInicial, saldoFinal };
}

function calcFidelidade_(realizado, previsto) {
  previsto = Number(previsto || 0);
  realizado = Number(realizado || 0);
  return previsto ? Math.round((realizado / previsto) * 100) : 0;
}

function getInitialRevenueRows_() {
  return [
    ['categoria', 'fevereiro', 'marco', 'abril'],
    ['COLETA', 605.40, 227.15, 275.10],
    ['BENFEITOR DA PAZ', 4949.30, 3917.50, 3665.00],
    ['LANCHONETE', 58.14, 119.25, 51.15],
    ['LIVRARIA', 329.52, 57.24, 164.52],
    ['EVENTOS', 9544.85, 133.00, 690.04],
    ['OUTROS SETORES', 75.20, 203.70, 39.73],
    ['COMUNH\u00c3O DE BENS OBRA', 16.88, 80.00, 80.00],
    ['COMUNH\u00c3O DE BENS CV', 93.00, 93.00, 60.00],
    ['COMUNH\u00c3O DE BENS CAL', 7341.70, 7067.80, 5358.00],
    ['DOA\u00c7\u00c3O', 0.00, 0.00, 0.00],
    ['RECUPERA\u00c7\u00c3O DE DESPESAS', 685.00, 685.00, 3484.86],
    ['REC. EMP. A PAGAR', 3202.81, 1621.19, 1659.20]
  ];
}

function getInitialExpenseRows_() {
  return [
    ['categoria', 'fevereiro', 'marco', 'abril'],
    ['Despesa de Comunh\u00e3o de Bens', 1336.39, 0, 0],
    ['Despesa de Comunh\u00e3o de Bens com a Igreja Local', 516.53, 0, 0],
    ['Repasse Concedido para Fundo de Previd\u00eancia', 900, 720, 900],
    ['Aluguel (todos)', 3369.16, 3369.16, 3369.16],
    ["Darf's", 0, 0, 0],
    ['Energia el\u00e9trica (CEV e CV)', 999.48, 782.91, 853.54],
    ['\u00c1gua e Esgoto (CEV e CV)', 128.28, 653.76, 720.36],
    ['Manuten\u00e7\u00e3o e Conserva\u00e7\u00e3o Predial', 0, 130, 283],
    ['Combust\u00edvel', 970, 980, 800],
    ['Pagamento de emprestimo adquirido', 3161.95, 2036.79, 3042.14],
    ['Despesas com Passagens', 1263.72, 1304.76, 1188.44],
    ['Despesa com Ensino de Gradua\u00e7\u00e3o', 35, 70, 35],
    ['Repasse Alimenta\u00e7\u00e3o C. vida', 1760, 1760, 1760],
    ['Telefone + internet + Recarga', 219.90, 184.20, 154.16],
    ['Repasse Energia el\u00e9trica C. vida', 0, 0, 0],
    ['Repasse \u00c1gua e Esgoto C. vida', 0, 0, 0],
    ['Sal\u00e1rios + encargos + vale + f\u00e9rias', 0, 0, 0],
    ['Despesa com Inscri\u00e7\u00e3o Reciclagem', 1810, 350, 0],
    ['Despesa com Retiros e Encontros', 1280, 1280, 1280],
    ['Repasse G\u00e1s C. Vida', 0, 81, 84],
    ['Repasse C. vida', 770, 770, 770],
    ['Liturgia', 0, 26, 100],
    ['CAP E CEV', 0, 0, 0],
    ['Despesas com Membros Desligados', 0, 0, 0],
    ['Despesas Banc\u00e1rias', 117.16, 101.31, 103.99],
    ['Lanches e Refei\u00e7\u00f5es', 0, 116.98, 0]
  ];
}

function getInitialCal10Rows_() {
  return [
    ['mes', 'previsto', 'realizado', 'fidelidade'],
    ['Fevereiro', 9391.46, 6932.60, 66],
    ['Mar\u00e7o', 9674.76, 6449.00, 78],
    ['Abril', 7500.00, 7521.41, 81]
  ];
}

function getInitialCal5Rows_() {
  return [
    ['mes', 'previsto', 'realizado', 'fidelidade'],
    ['Fevereiro', 4695.73, 3244.26, 46],
    ['Mar\u00e7o', 3487.38, 3365.00, 56],
    ['Abril', 3750.00, 3169.89, 54]
  ];
}