# Sistema de Prestação de Contas

Sistema web desenvolvido em **Google Apps Script** com **Google Sheets como banco de dados**, voltado para controle, visualização e apresentação de prestação de contas.

O projeto possui login interno, controle de usuários, dashboard financeiro, editor de dados e modo apresentação em tela cheia.

---

## Funcionalidades

- Login com usuário e senha
- Controle de sessão
- Perfis de acesso:
  - **Admin:** pode editar dados, usuários e configurações
  - **Visualizador:** pode apenas visualizar dashboard e apresentação
- Dashboard financeiro
- Cadastro e edição de receitas
- Cadastro e edição de despesas
- Configuração de meses da apresentação
- Configuração do período apresentado
- Configuração da missão e comunidade
- Modo apresentação em tela cheia
- Seleção dos slides que farão parte da apresentação
- Ordenação dos slides
- Perfil de apresentação:
  - **Assembleia:** mostra dados financeiros em porcentagem
  - **Conselho Local:** mostra dados financeiros em valores reais
- Slides extras com dados da Assembleia
- QR Code para PIX
- QR Code para WhatsApp
- Logo personalizada
- Favicon personalizado
- Layout responsivo para desktop e celular

---

## Tecnologias usadas

- Google Apps Script
- Google Sheets
- HTML
- CSS
- JavaScript
- Chart.js
- GitHub para hospedagem do favicon

---

## Estrutura dos arquivos

```txt
Code.gs
Database.gs
Auth.gs
index.html
style.html
script.html
```

---

## Estrutura das abas no Google Sheets

O sistema utiliza uma planilha como banco de dados. As principais abas são:

```txt
Config
Usuarios
Receitas
Despesas
CAL10
CAL5
Assembleia
AssembleiaEventos
```

---

## Aba Config

Armazena configurações gerais do sistema, como:

* período da apresentação
* missão
* comunidade
* saldo inicial
* meses utilizados
* slides visíveis
* ordem dos slides
* perfil da apresentação

Exemplo:

```txt
chave | valor
periodo | Junho a Agosto - 2026
missao | Missão Aparecida
comunidade | Comunidade Católica Shalom
meses | Junho,Julho,Agosto
perfil_apresentacao | conselho
```

---

## Aba Usuarios

Armazena os usuários do sistema.

```txt
id | nome | email | senha_hash | salt | role | is_master | ativo | criado_em
```

### Perfis disponíveis

```txt
admin
viewer
```

O perfil `viewer` não pode editar nenhuma informação.

---

## Abas Receitas e Despesas

Essas abas armazenam os valores financeiros.

Mesmo que no sistema apareça como:

```txt
Mês 1
Mês 2
Mês 3
```

internamente a planilha ainda pode usar chaves técnicas como:

```txt
fevereiro
marco
abril
```

Essas colunas representam, respectivamente:

```txt
Mês 1
Mês 2
Mês 3
```

Então não renomeie essas colunas manualmente sem ajustar o código.

---

## Aba CAL10 e CAL5

Armazenam os dados de Comunhão de Bens:

```txt
mes | previsto | realizado | fidelidade
```

---

## Aba Assembleia

Armazena dados complementares usados nos slides da Assembleia, como:

* irmãos na obra
* benfeitores da paz
* pessoas na obra
* casais
* jovens
* adultos
* consultas
* exames
* medicamentos
* irmãos socorridos
* ações evangelizadoras
* pessoas alcançadas
* mensagem final
* chave PIX
* link do WhatsApp

---

## Aba AssembleiaEventos

Armazena os eventos exibidos nos slides da Assembleia.

```txt
evento | receita | despesa | superavit | observacao
```

---

## Instalação

1. Crie uma planilha no Google Sheets.
2. Acesse:

```txt
Extensões > Apps Script
```

3. Crie os arquivos do projeto:

```txt
Code.gs
Database.gs
Auth.gs
index.html
style.html
script.html
```

4. Cole o código correspondente em cada arquivo.
5. Salve o projeto.
6. Execute a função:

```js
setupDatabase
```

Use essa função apenas na primeira instalação.

---

## Atenção sobre setupDatabase

A função `setupDatabase` recria as abas principais.

Use somente na instalação inicial.

Depois que o sistema já estiver em uso, **não execute novamente**, pois pode sobrescrever dados existentes.

Traduzindo para humanos com pressa: esse botão é quase nuclear. Não aperta por esporte.

---

## Reparo de abas

Caso alguma aba seja apagada ou renomeada acidentalmente, use:

```js
repararAbasFaltantesSemResetar
```

Essa função tenta recriar apenas abas faltantes sem resetar as existentes.

---

## Publicação como Web App

No Apps Script:

1. Clique em **Implantar**
2. Clique em **Nova implantação**
3. Selecione **App da Web**
4. Configure:

```txt
Executar como: Eu
Quem pode acessar: Qualquer pessoa com uma Conta Google
```

5. Clique em **Implantar**
6. Copie o link terminado em:

```txt
/exec
```

Use sempre o link `/exec`, não o `/dev`.

---

## Atualização do sistema

Sempre que alterar código:

1. Salve os arquivos.
2. Vá em:

```txt
Implantar > Gerenciar implantações
```

3. Clique no lápis da implantação.
4. Em versão, escolha:

```txt
Nova versão
```

5. Clique em **Implantar**.
6. Atualize o navegador com:

```txt
Ctrl + F5
```

---

## Login

O sistema usa login interno com usuário e senha.

As senhas são armazenadas usando:

* hash
* salt

A senha real não deve ficar salva em texto puro na planilha.

---

## Segurança

O sistema possui:

* autenticação interna
* sessão por token
* controle de perfil
* bloqueio de funções administrativas no backend
* bloqueio visual no frontend para usuários visualizadores
* proteção contra usuários duplicados ativos com o mesmo e-mail

Mesmo assim, como o sistema roda sobre Google Apps Script e Google Sheets, recomenda-se:

* não compartilhar a planilha com pessoas não autorizadas
* manter poucos administradores
* evitar senhas fracas
* não deixar usuários duplicados ativos
* publicar o Web App apenas para contas Google autorizadas, quando possível

---

## Permissões por perfil

| Recurso                  | Admin | Visualizador |
| ------------------------ | ----: | -----------: |
| Ver dashboard            |   Sim |          Sim |
| Ver apresentação         |   Sim |          Sim |
| Editar receitas          |   Sim |          Não |
| Editar despesas          |   Sim |          Não |
| Editar configurações     |   Sim |          Não |
| Editar usuários          |   Sim |          Não |
| Alterar ordem dos slides |   Sim |          Não |

---

## Modo apresentação

A tela de apresentação possui:

* modo tela cheia
* navegação por botões
* navegação por teclado
* seleção dos slides exibidos
* ordenação dos slides
* perfil Assembleia
* perfil Conselho Local

### Atalhos

```txt
Seta direita: próximo slide
Espaço: próximo slide
Seta esquerda: slide anterior
Esc: sair do modo apresentação
```

---

## Perfis de apresentação

### Assembleia

Mostra dados financeiros em porcentagem.

### Conselho Local

Mostra dados financeiros em valores reais.

Os slides exibidos dependem da seleção feita na configuração, independentemente do perfil escolhido.

---

## QR Code no slide final

O slide final pode exibir:

* QR Code do PIX
* QR Code do WhatsApp

Os dados são preenchidos no Editor, na seção de Assembleia.

Para WhatsApp, use um link no formato:

```txt
https://wa.me/5511999999999
```

Ou com mensagem pronta:

```txt
https://wa.me/5511999999999?text=Olá%2C%20quero%20falar%20sobre%20a%20Providência
```

---

## Favicon

O favicon é configurado no `Code.gs`, dentro da função `doGet()`:

```js
.setFaviconUrl('https://raw.githubusercontent.com/usuario/repositorio/main/favicon.png')
```

O link precisa ser direto para uma imagem pública.

Links normais do Google Drive ou páginas do GitHub não funcionam bem como favicon.

Use preferencialmente um link `raw.githubusercontent.com`.

Exemplo:

```js
function doGet() {
  const template = HtmlService.createTemplateFromFile('index');

  return template
    .evaluate()
    .setTitle('Prestação de Contas')
    .setFaviconUrl('https://raw.githubusercontent.com/DudaBuss82/prestacao-assets/main/ab6761610000e5eb4ef45a2c8a0abb54128155e1-removebg-preview.png?v=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
```

---

## Integração com Google Sites

O sistema pode ser incorporado em um Google Sites.

No Google Sites:

```txt
Inserir > Incorporar > URL
```

Cole o link `/exec` do Web App.

Para apresentação em tela cheia, recomenda-se abrir o sistema em uma nova aba, pois o Google Sites pode limitar tela cheia dentro do iframe.

---

## Boas práticas

* Não execute `setupDatabase` depois que o sistema estiver em uso.
* Não renomeie abas manualmente sem ajustar o código.
* Não deixe e-mails duplicados ativos na aba `Usuarios`.
* Publique sempre uma nova versão após alterar código.
* Use o link `/exec` para acesso final.
* Use `Ctrl + F5` após atualizar a implantação.
* Faça backup da planilha antes de grandes alterações.

---

## Possíveis problemas

### Acentos quebrados

Verifique se os textos estão salvos corretamente nos arquivos HTML/JS e evite copiar código por editores que alterem codificação.

### Tela branca após logout

Verifique a função `doLogout()` no `script.html`.

### Erro getDataRange de null

Alguma aba esperada não existe ou está com nome diferente.

Use:

```js
repararAbasFaltantesSemResetar
```

### Login lento

O sistema carrega dados da planilha após autenticação. O desempenho depende do tamanho da planilha e da resposta do Apps Script.

### Logo quebrado

Verifique se a logo está embutida corretamente ou se o link usado está público e acessível.

### Favicon não atualiza

O navegador pode manter favicon antigo em cache.

Para forçar atualização, altere o final do link:

```txt
?v=1
```

para:

```txt
?v=2
```

ou outro número.



---

## Fluxo de Git Commit e Deploy no Apps Script

Este projeto usa:

- **Git/GitHub** para versionamento do código
- **clasp** para sincronizar o código local com o Google Apps Script
- **Google Apps Script Web App** para publicação do sistema

O fluxo recomendado é:

```txt
VS Code / Pasta local
↓
Git commit
↓
GitHub
↓
clasp push
↓
clasp version
↓
clasp deploy ou redeploy
```

---

## 1. Antes de começar

Abra o terminal dentro da pasta do projeto.

Exemplo:

```bash
cd "C:\Users\Maria\Desktop\Sistema prestação de contas - prod\Sistema-presta-o-de-contas---Prod"
```

Confira se está na branch correta:

```bash
git status
```

Se aparecer algo como:

```txt
On branch main
Your branch is up to date with 'origin/main'
```

está tudo certo.

---

## 2. Conferir alterações

Antes de salvar qualquer alteração, confira o que mudou:

```bash
git status
```

Para ver detalhes das alterações:

```bash
git diff
```

---

## 3. Salvar alterações no Git

Adicione todos os arquivos alterados:

```bash
git add .
```

Crie um commit com uma mensagem clara:

```bash
git commit -m "Descreve aqui o que foi alterado"
```

Exemplo:

```bash
git commit -m "Ajusta slides finais com QR Code"
```

Envie para o GitHub:

```bash
git push
```

---

## 4. Enviar código local para o Apps Script

Depois do commit, envie o código local para o projeto do Apps Script:

```bash
clasp push
```

Esse comando envia os arquivos locais para o Apps Script. Arquivos `.js` locais são convertidos para `.gs` no Apps Script.

---

## 5. Criar uma nova versão do Apps Script

Depois do `clasp push`, crie uma nova versão:

```bash
clasp version "Descrição da versão"
```

Exemplo:

```bash
clasp version "Ajusta QR Code no slide final"
```

O terminal vai responder algo parecido com:

```txt
Created version 39
```

Guarde esse número da versão.

---

## 6. Ver implantações existentes

Para listar as implantações do projeto:

```bash
clasp deployments
```

Procure a implantação de produção e copie o `deploymentId`.

Ele costuma ser parecido com:

```txt
AKfycbxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

---

## 7. Criar uma nova implantação

Use este comando apenas se ainda não existir uma implantação de produção.

```bash
clasp deploy --versionNumber NUMERO_DA_VERSAO --description "Produção"
```

Exemplo:

```bash
clasp deploy --versionNumber 39 --description "Produção"
```

Esse comando cria uma nova implantação.

---

## 8. Atualizar uma implantação existente

Se já existe uma implantação de produção, o ideal é atualizar ela em vez de criar uma nova.

Use:

```bash
clasp redeploy --deploymentId ID_DA_IMPLANTACAO --versionNumber NUMERO_DA_VERSAO --description "Descrição da atualização"
```

Exemplo:

```bash
clasp redeploy --deploymentId AKfycbxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx --versionNumber 39 --description "Produção - QR Code no slide final"
```

Assim o link `/exec` da implantação continua o mesmo, mas passa a usar a versão nova.

---

## 9. Fluxo completo recomendado

Use este fluxo sempre que alterar o sistema:

```bash
git status
git add .
git commit -m "Descreve a alteração"
git push

clasp push
clasp version "Descrição da versão"
clasp deployments
clasp redeploy --deploymentId ID_DA_IMPLANTACAO --versionNumber NUMERO_DA_VERSAO --description "Descrição da atualização"
```

Exemplo real:

```bash
git status
git add .
git commit -m "Ajusta permissão do perfil visualizador"
git push

clasp push
clasp version "Ajusta permissão do perfil visualizador"
clasp deployments
clasp redeploy --deploymentId AKfycbxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx --versionNumber 40 --description "Produção - ajuste de permissões"
```

---

## 10. Quando usar cada comando

### `git status`

Mostra o que foi alterado.

```bash
git status
```

### `git add .`

Prepara todos os arquivos alterados para o commit.

```bash
git add .
```

### `git commit`

Salva um ponto de versão local.

```bash
git commit -m "Mensagem do commit"
```

### `git push`

Envia os commits para o GitHub.

```bash
git push
```

### `clasp push`

Envia o código local para o Apps Script.

```bash
clasp push
```

### `clasp pull`

Baixa o código atual do Apps Script para a pasta local.

Use quando alguém alterou algo diretamente no editor do Apps Script.

```bash
clasp pull
```

### `clasp version`

Cria uma versão imutável do Apps Script.

```bash
clasp version "Descrição"
```

### `clasp deployments`

Lista as implantações existentes.

```bash
clasp deployments
```

### `clasp deploy`

Cria uma nova implantação.

```bash
clasp deploy --versionNumber NUMERO_DA_VERSAO --description "Descrição"
```

### `clasp redeploy`

Atualiza uma implantação existente.

```bash
clasp redeploy --deploymentId ID_DA_IMPLANTACAO --versionNumber NUMERO_DA_VERSAO --description "Descrição"
```

---

## 11. Atenção importante

Antes de rodar:

```bash
clasp push
```

confira se você está na pasta correta:

```bash
cd
```

O `clasp push` sobrescreve o código do Apps Script com o conteúdo da pasta local.

Não rode `clasp push` se você não tiver certeza de que os arquivos locais estão corretos.

---

## 12. Se editar direto no Apps Script

Se alguma alteração for feita direto no editor do Apps Script, primeiro puxe para o PC:

```bash
clasp pull
```

Depois salve no GitHub:

```bash
git add .
git commit -m "Atualiza código vindo do Apps Script"
git push
```

---

## 13. Se editar no VS Code

Se a alteração for feita no VS Code:

```bash
git add .
git commit -m "Descreve a alteração"
git push
clasp push
```

Depois crie versão e atualize a implantação:

```bash
clasp version "Descrição da versão"
clasp deployments
clasp redeploy --deploymentId ID_DA_IMPLANTACAO --versionNumber NUMERO_DA_VERSAO --description "Descrição da atualização"
```

---

## 14. Problemas comuns

### Erro: too many arguments for create-deployment

Use flags em vez de argumentos soltos:

Errado:

```bash
clasp deploy 39 "Produção"
```

Certo:

```bash
clasp deploy --versionNumber 39 --description "Produção"
```

### Deploy não atualizou o link

Provavelmente foi criada uma nova implantação em vez de atualizar a existente.

Use:

```bash
clasp deployments
```

Depois atualize a implantação correta com:

```bash
clasp redeploy --deploymentId ID_DA_IMPLANTACAO --versionNumber NUMERO_DA_VERSAO --description "Produção"
```

### Alterei o código mas o site não mudou

Verifique se você fez todos os passos:

```bash
clasp push
clasp version "Descrição"
clasp redeploy --deploymentId ID_DA_IMPLANTACAO --versionNumber NUMERO_DA_VERSAO --description "Descrição"
```

Depois atualize o navegador com:

```txt
Ctrl + F5
```

---

## 15. Boas práticas de versionamento e deploy

- Sempre faça commit antes de rodar `clasp push`.
- Sempre use `clasp redeploy` para produção, não crie uma implantação nova sem necessidade.
- Guarde o `deploymentId` da produção.
- Use mensagens claras nos commits e versões.
- Não edite no Apps Script e no VS Code ao mesmo tempo sem usar `clasp pull`.
- Antes de mudanças grandes, faça backup da planilha.


---

## Status do projeto

Projeto em uso e evolução contínua.

Como todo sistema em Apps Script, ele funciona bem, desde que ninguém aperte o botão errado, renomeie uma aba no impulso ou tente transformar uma planilha em um ERP multinacional antes do café.

```
